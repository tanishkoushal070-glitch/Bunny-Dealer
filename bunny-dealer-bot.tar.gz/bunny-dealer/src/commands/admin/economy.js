const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { getOrCreateUser, addCurrency, removeCurrency, formatCurrency } = require("../../utils/economy");
const User = require("../../models/User");
const Log = require("../../models/Log");
const { successEmbed, errorEmbed } = require("../../utils/embed");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("economy")
    .setDescription("💼 Manage user economy (Admin only)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sub) =>
      sub.setName("add").setDescription("Add currency to a user")
        .addUserOption((o) => o.setName("user").setDescription("Target user").setRequired(true))
        .addStringOption((o) => o.setName("currency").setDescription("Currency type").setRequired(true).addChoices({ name: "Grass", value: "grass" }, { name: "Carrots", value: "carrots" }))
        .addIntegerOption((o) => o.setName("amount").setDescription("Amount to add").setRequired(true).setMinValue(1))
    )
    .addSubcommand((sub) =>
      sub.setName("remove").setDescription("Remove currency from a user")
        .addUserOption((o) => o.setName("user").setDescription("Target user").setRequired(true))
        .addStringOption((o) => o.setName("currency").setDescription("Currency type").setRequired(true).addChoices({ name: "Grass", value: "grass" }, { name: "Carrots", value: "carrots" }))
        .addIntegerOption((o) => o.setName("amount").setDescription("Amount to remove").setRequired(true).setMinValue(1))
    )
    .addSubcommand((sub) =>
      sub.setName("set").setDescription("Set a user's currency to a specific amount")
        .addUserOption((o) => o.setName("user").setDescription("Target user").setRequired(true))
        .addStringOption((o) => o.setName("currency").setDescription("Currency type").setRequired(true).addChoices({ name: "Grass", value: "grass" }, { name: "Carrots", value: "carrots" }))
        .addIntegerOption((o) => o.setName("amount").setDescription("Amount to set").setRequired(true).setMinValue(0))
    )
    .addSubcommand((sub) =>
      sub.setName("reset").setDescription("Reset a user's wallet to 0")
        .addUserOption((o) => o.setName("user").setDescription("Target user").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub.setName("refund").setDescription("Refund a user (add with refund note)")
        .addUserOption((o) => o.setName("user").setDescription("Target user").setRequired(true))
        .addStringOption((o) => o.setName("currency").setDescription("Currency type").setRequired(true).addChoices({ name: "Grass", value: "grass" }, { name: "Carrots", value: "carrots" }))
        .addIntegerOption((o) => o.setName("amount").setDescription("Amount to refund").setRequired(true).setMinValue(1))
        .addStringOption((o) => o.setName("reason").setDescription("Reason for refund").setRequired(false))
    ),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const sub = interaction.options.getSubcommand();
    const target = interaction.options.getUser("user");
    const currency = interaction.options.getString("currency") || "grass";
    const amount = interaction.options.getInteger("amount");

    await getOrCreateUser(target.id, target.username);

    const logAction = async (action, amt) => {
      await Log.create({ guildId: interaction.guildId, type: "admin", userId: interaction.user.id, targetId: target.id, action, amount: amt, currency });
    };

    if (sub === "add") {
      await addCurrency(target.id, currency, amount, interaction.guildId, `admin add by ${interaction.user.username}`);
      await logAction("admin_add", amount);
      return interaction.editReply({ embeds: [successEmbed("Currency Added", `Added ${formatCurrency(amount, currency)} to ${target.username}.`)] });
    }

    if (sub === "remove") {
      const result = await removeCurrency(target.id, currency, amount, interaction.guildId, `admin remove by ${interaction.user.username}`);
      if (!result) return interaction.editReply({ embeds: [errorEmbed("Failed", `${target.username} doesn't have enough ${currency}!`)] });
      await logAction("admin_remove", amount);
      return interaction.editReply({ embeds: [successEmbed("Currency Removed", `Removed ${formatCurrency(amount, currency)} from ${target.username}.`)] });
    }

    if (sub === "set") {
      await User.findOneAndUpdate({ userId: target.id }, { [currency]: amount });
      await logAction("admin_set", amount);
      return interaction.editReply({ embeds: [successEmbed("Currency Set", `Set ${target.username}'s ${currency} to ${formatCurrency(amount, currency)}.`)] });
    }

    if (sub === "reset") {
      await User.findOneAndUpdate({ userId: target.id }, { grass: 0, carrots: 0 });
      await logAction("admin_reset", 0);
      return interaction.editReply({ embeds: [successEmbed("Wallet Reset", `Reset ${target.username}'s wallet to 0.`)] });
    }

    if (sub === "refund") {
      const reason = interaction.options.getString("reason") || "admin refund";
      await addCurrency(target.id, currency, amount, interaction.guildId, reason);
      await logAction("admin_refund", amount);
      return interaction.editReply({ embeds: [successEmbed("Refund Issued", `Refunded ${formatCurrency(amount, currency)} to ${target.username}.\nReason: ${reason}`)] });
    }
  },
};
