const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require("discord.js");
const Settings = require("../../models/Settings");
const { COLORS, baseEmbed } = require("../../utils/embed");

async function getOrCreateSettings(guildId) {
  let s = await Settings.findOne({ guildId });
  if (!s) s = await Settings.create({ guildId });
  return s;
}

function formatUptime(ms) {
  const sec = Math.floor(ms / 1000);
  const min = Math.floor(sec / 60);
  const hr = Math.floor(min / 60);
  const day = Math.floor(hr / 24);
  return `${day}d ${hr % 24}h ${min % 60}m ${sec % 60}s`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("24-7")
    .setDescription("🤖 View and control bot 24/7 status")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    await interaction.deferReply();
    const settings = await getOrCreateSettings(interaction.guildId);
    const client = interaction.client;

    const uptime = formatUptime(Date.now() - client.startTime);
    const ping = client.ws.ping;
    const botActive = settings.botActive;

    const embed = baseEmbed(botActive ? COLORS.success : COLORS.error)
      .setTitle("🤖 Bunny Dealer — 24/7 Control")
      .addFields(
        { name: "🟢 Status", value: botActive ? "**Online**" : "**Offline**", inline: true },
        { name: "📡 Ping", value: `\`${ping}ms\``, inline: true },
        { name: "⏱️ Uptime", value: uptime, inline: true },
        { name: "🔄 Last Restart", value: new Date(Date.now() - (Date.now() - client.startTime)).toUTCString(), inline: false },
        { name: "⏰ Runtime", value: `Since <t:${Math.floor(client.startTime / 1000)}:R>`, inline: false }
      );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("bot_activate")
        .setLabel("✅ Activate")
        .setStyle(ButtonStyle.Success)
        .setDisabled(botActive),
      new ButtonBuilder()
        .setCustomId("bot_deactivate")
        .setLabel("⏹️ Deactivate")
        .setStyle(ButtonStyle.Danger)
        .setDisabled(!botActive)
    );

    const msg = await interaction.editReply({ embeds: [embed], components: [row] });

    const collector = msg.createMessageComponentCollector({
      filter: (i) => i.user.id === interaction.user.id,
      time: 30000,
    });

    collector.on("collect", async (btn) => {
      const s = await getOrCreateSettings(interaction.guildId);

      if (btn.customId === "bot_activate") {
        s.botActive = true;
        s.lastActivated = new Date();
        await s.save();
        embed.setColor(COLORS.success).spliceFields(0, 1, { name: "🟢 Status", value: "**Online**", inline: true });
        row.components[0].setDisabled(true);
        row.components[1].setDisabled(false);
        await btn.update({ embeds: [embed], components: [row] });
      } else if (btn.customId === "bot_deactivate") {
        s.botActive = false;
        s.lastDeactivated = new Date();
        await s.save();
        embed.setColor(COLORS.error).spliceFields(0, 1, { name: "🔴 Status", value: "**Offline**", inline: true });
        row.components[0].setDisabled(false);
        row.components[1].setDisabled(true);
        await btn.update({ embeds: [embed], components: [row] });
      }
    });

    collector.on("end", () => interaction.editReply({ components: [] }).catch(() => {}));
  },
};
